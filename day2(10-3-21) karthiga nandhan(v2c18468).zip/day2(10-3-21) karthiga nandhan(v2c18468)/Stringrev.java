package staticex;

class Stringrev1 {
	
		public static String reverseString(String str){ 
		char ch[]=str.toCharArray();  
	    String rev="";  
	    for(int i=ch.length-1;i>=0;i--){  
	        rev+=ch[i];  
	    }  
	    return rev;  
	}  
	}  
class Stringrev extends Stringrev1
{
	public static void main(String[] args) {
		 System.out.println(Stringrev1.reverseString("karthi"));  
		    System.out.println(Stringrev1.reverseString("javatest"));      
		    }  
		}  
		// TODO Auto-generated method stub
		

	


