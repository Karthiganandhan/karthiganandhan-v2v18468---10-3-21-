package finalkeyword;


		
		
		final class XYZ{  
		}  
			     
		public class Finalclass extends XYZ {

			
		   void demo(){
		      System.out.println("My Method");
		   }  
		   public static void main(String args[]){  
			   Finalclass obj= new Finalclass(); 
		      obj.demo();
		   }  
		
		// TODO Auto-generated method stub

	}


