package finalkeyword;



class sub{ 
	final int i=9;
	final int j;   //blan final var can change val in constructor
	sub(int n)
	{
		j=n;
	}
	   final void demo(){
		    i=0;//final keyword should remove
	      System.out.println("XYZ Class Method");
	   }  
	}  
public class Finalmeth extends sub {

	public static void main(String[] args) {
		
		 Finalmeth obj= new Finalmeth();  
	      obj.demo();  
	   }  
	}
		
//if we try to overridd means we get error		
				     
			