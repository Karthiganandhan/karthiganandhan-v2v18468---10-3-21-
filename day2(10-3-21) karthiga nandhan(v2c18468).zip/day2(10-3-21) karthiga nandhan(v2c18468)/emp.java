package constex;

public class emp
{
emp()
{
this(5);

System.out.println("The Default constructor");
}
emp(int id)
{
this(50, "nandha");
System.out.println("id:"+id);
}
emp(int sal, String y)
{
System.out.println("name:"+y);

System.out.println("salary:"+sal);
}
public static void main(String args[])
{
new emp();
}
}