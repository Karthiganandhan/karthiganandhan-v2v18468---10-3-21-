package staticex;

import java.io.IOException;

class Staticex1 {

	

	static int a=m1();
	static int m1()
	{
	
	return 20+10;
	}	}
class Staticex extends Staticex1
{
	public static void main(String args[])throws IOException
	{
	Staticex1.m1(); 
	System.out.println("sum : "+a);

	}
	}


