package constex;

class Base
{
String name;
Base()
{
this("nandha");
}
Base(String name)
{
this.name = "karthi";
System.out.println("name:"
+name);
}
}
class constructorschain extends Base
{
	constructorschain()
{
System.out.println("");
}
	constructorschain(String name)
{
super(name);

System.out.println("name:"+name);
}
public static void main(String args[])
{
	 new constructorschain("nandha");
}
}
